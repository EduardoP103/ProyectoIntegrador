sap.ui.define([
	"./utilUI",
	"./utilController"
], function( utilUI , utilController) {
	"use strict";
	return {
		utilUI: utilUI,
		utilController: utilController,
	};
});
